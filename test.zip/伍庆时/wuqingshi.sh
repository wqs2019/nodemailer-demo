#!/bin/bash
acountName=""
caidan(){
echo "######################"
echo "         菜单         "
echo "       输入1注册      "
echo "       输入2登入      "
echo "       输入3登出      "
echo "######################"
}
maincaidan(){
echo "######################"
echo "        主菜单        "
echo "       1、查询        "
echo "       2、充值        "
echo "       3、消费        "
echo "       4、退出        "
echo "######################"
}
zuce(){
read -p "请输入您要注册的用户名:" name
flag=$(mysql -uroot -p'WUqingshi..666' -D bank 2>/dev/null -e "select * from test where name = '$name';" | awk 'NR==2{print$1}')
if [ -n "$flag" ]
then
echo "用户名已存在！！"
else
	for ((i=1; i<3; i++))
	do
	echo "请输入您的密码："
	read -s password
	if [ -z "$password" ];then
	echo "您输入的密码为空："
	else
	echo "请再次输入您的密码"
	read -s repassword
		if [ $password -eq $repassword ];then
		mysql -uroot -p'WUqingshi..666' -D bank 2>/dev/null -e "insert into test value('$name','$password',100);"
		let i++
		echo "注册成功！一秒后返回主菜单！！"
		else
		echo "您两次输入的密码不一致，请重新输入！"
		fi
	fi
	done
	sleep 1;
fi
}
denglv(){
yes=0
for((i=1; i<4; i++))
do
read -p "请输入您的用户名：" name
echo "请输入您的密码"
read -s password
flag=$(mysql -uroot -p'WUqingshi..666' -D bank 2>/dev/null -e "select name from test where name = '$name' and password = '$password';" | awk 'NR==2{print$1}')
if [ -z "$flag" ];then
echo "用户名或密码错误！"
else
acountName=$name
yes=1
i=4
fi
done
if [ $yes -eq 1 ];then
caozuo
fi
}
chaxun(){
money=$(mysql -uroot -p'WUqingshi..666' -D bank 2>/dev/null -e "select sum from test where name = '$acountName';" | awk 'NR==2{print$1}')
echo $acountName
echo "您的账户余额是:￥$money"
}

chongzhi(){
read -p "请输入您要充值的金额（充值金额必须为50的整数）：" m
if [ `expr $m % 50` -eq 0 ];then
echo $m
mysql -uroot -p'WUqingshi..666' -D bank 2>/dev/null -e "update test set sum=sum+'$m' where name = '$acountName';"
echo "充值成功！"

else
echo "您输入的金额不是50的整数，充值失败！"
fi
}
xiaofei(){
read -p "请输入您要支付的金额：" pay
money=$(mysql -uroot -p'WUqingshi..666' -D bank 2>/dev/null -e "select sum from test where name = '$acountName';" | awk 'NR==2{print$1}')
if [ $pay -gt $money ];then
echo "您的余额不足！"
else
mysql -uroot -p'WUqingshi..666' -D bank 2>/dev/null -e "update test set sum=sum-'$pay' where name = '$acountName';"
echo "支付成功！"
fi
}
caozuo(){
clear
while [ 1 ]
do
maincaidan
read -p "输入主菜单号：" j
case $j in
1)
	echo "查询"
	chaxun;;
2)
        echo "充值"
        chongzhi;;
3)
        echo "消费"
        xiaofei;;
4)	
	echo "退出"
	clear
	break;;
esac
done
}



while [ 1 ]
do
caidan
read -p "输入菜单号：" i
case $i in
1)
	echo "注册"
	zuce;;
2)
	echo "登录"
	denglv;;
3)
	echo "登出" && exit
	;;
esac
done
